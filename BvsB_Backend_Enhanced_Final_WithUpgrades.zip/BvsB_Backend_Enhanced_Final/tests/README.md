# Tests
Automated tests using Mocha and Chai.
# Sockets
Real-time user updates via WebSockets (Socket.io).